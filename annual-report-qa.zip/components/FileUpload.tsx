import { useState, useCallback } from "react"
import { Upload, FileText, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { useRouter } from "next/navigation"

export default function FileUpload() {
  const [file, setFile] = useState<File | null>(null)
  const [isDragging, setIsDragging] = useState(false)
  const router = useRouter()

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0]
    if (selectedFile && selectedFile.type === "application/pdf") {
      setFile(selectedFile)
    }
  }

  const handleDrop = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault()
    setIsDragging(false)
    const droppedFile = e.dataTransfer.files[0]
    if (droppedFile && droppedFile.type === "application/pdf") {
      setFile(droppedFile)
    }
  }, [])

  const handleDragOver = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault()
    setIsDragging(true)
  }, [])

  const handleDragLeave = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault()
    setIsDragging(false)
  }, [])

  const handleContinue = () => {
    if (!file) return
    // Here you would typically handle the file upload
    router.push("/analyze")
  }

  return (
    <Card className="w-full max-w-2xl border-border shadow-lg">
      <CardHeader className="text-center">
        <CardTitle className="text-2xl text-secondary dark:text-secondary-foreground">
          Upload Your Financial Report
        </CardTitle>
        <CardDescription>Upload a financial report to begin analyzing it with AI</CardDescription>
      </CardHeader>
      <CardContent>
        <div
          className={`border-2 border-dashed rounded-lg p-12 text-center cursor-pointer transition-colors ${
            isDragging ? "border-primary bg-primary/10" : "border-border hover:border-primary/50"
          }`}
          onDrop={handleDrop}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onClick={() => document.getElementById("file-upload")?.click()}
        >
          <div className="flex flex-col items-center justify-center gap-4">
            <div className="h-16 w-16 rounded-full bg-accent flex items-center justify-center">
              <Upload className="h-8 w-8 text-primary" />
            </div>
            <div className="text-lg font-medium">Drag and drop your PDF here</div>
            <div className="text-sm text-muted-foreground">
              <span className="text-primary font-medium">Click to browse</span> or drag and drop
            </div>
            <div className="text-xs text-muted-foreground">PDF (max. 20MB)</div>
            <input
              id="file-upload"
              type="file"
              accept=".pdf"
              className="hidden"
              onChange={handleFileChange}
            />
          </div>
        </div>

        {file && (
          <div className="flex items-center justify-between p-4 mt-4 bg-accent rounded-md">
            <div className="flex items-center gap-2">
              <FileText className="h-5 w-5 text-primary" />
              <span className="text-sm font-medium truncate max-w-[200px] md:max-w-[400px]">
                {file.name}
              </span>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setFile(null)}
              className="text-muted-foreground"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        )}
      </CardContent>
      <CardFooter className="flex justify-center">
        <Button
          onClick={handleContinue}
          disabled={!file}
          className="bg-primary hover:bg-primary/90 text-primary-foreground w-full md:w-auto"
        >
          Continue
        </Button>
      </CardFooter>
    </Card>
  )
} 