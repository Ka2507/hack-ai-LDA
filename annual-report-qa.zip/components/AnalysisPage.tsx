import { useState } from "react"
import { ArrowLeft, FileText, History, Compare } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useRouter } from "next/navigation"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function AnalysisPage() {
  const [currentView, setCurrentView] = useState<"analysis" | "comparison" | "history">("analysis")
  const [comparedFiles, setComparedFiles] = useState<File[]>([])
  const router = useRouter()

  const handleBack = () => {
    router.push("/")
  }

  const handleFileUpload = (file: File) => {
    setComparedFiles([...comparedFiles, file])
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <Button variant="outline" onClick={handleBack}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Main
          </Button>
          <div className="flex gap-4">
            <Button
              variant={currentView === "comparison" ? "default" : "outline"}
              onClick={() => setCurrentView("comparison")}
            >
              <Compare className="h-4 w-4 mr-2" />
              Compare Documents
            </Button>
            <Button
              variant={currentView === "history" ? "default" : "outline"}
              onClick={() => setCurrentView("history")}
            >
              <History className="h-4 w-4 mr-2" />
              View History
            </Button>
          </div>
        </div>

        {/* Main Content */}
        <Tabs value={currentView} className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="analysis" onClick={() => setCurrentView("analysis")}>
              Analysis
            </TabsTrigger>
            <TabsTrigger value="comparison" onClick={() => setCurrentView("comparison")}>
              Comparison
            </TabsTrigger>
            <TabsTrigger value="history" onClick={() => setCurrentView("history")}>
              History
            </TabsTrigger>
          </TabsList>

          <TabsContent value="analysis" className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Analysis Section */}
              <Card>
                <CardHeader>
                  <CardTitle>Document Analysis</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <h3 className="font-semibold mb-2">Key Financial Metrics</h3>
                      <p className="text-muted-foreground">Loading metrics...</p>
                    </div>
                    <div>
                      <h3 className="font-semibold mb-2">Trend Analysis</h3>
                      <p className="text-muted-foreground">Loading trends...</p>
                    </div>
                    <div>
                      <h3 className="font-semibold mb-2">Recommendations</h3>
                      <p className="text-muted-foreground">Loading recommendations...</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Chat Section */}
              <Card>
                <CardHeader>
                  <CardTitle>Chat with AI Assistant</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-[500px] overflow-y-auto space-y-4">
                    {/* Chat messages will go here */}
                  </div>
                  <div className="mt-4">
                    {/* Chat input will go here */}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="comparison" className="mt-6">
            <div className="space-y-6">
              {/* File Upload Section */}
              <Card>
                <CardHeader>
                  <CardTitle>Compare Documents</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center gap-2">
                      <FileText className="h-4 w-4" />
                      <span>Current Document: document1.pdf</span>
                    </div>
                    <div className="border-2 border-dashed rounded-lg p-8 text-center">
                      <p className="text-muted-foreground">Upload another document to compare</p>
                      <input
                        type="file"
                        accept=".pdf"
                        className="mt-4"
                        onChange={(e) => e.target.files?.[0] && handleFileUpload(e.target.files[0])}
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Comparison View */}
              {comparedFiles.length > 0 && (
                <div className="grid grid-cols-2 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>Document 1</CardTitle>
                    </CardHeader>
                    <CardContent>
                      {/* Document 1 analysis */}
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader>
                      <CardTitle>Document 2</CardTitle>
                    </CardHeader>
                    <CardContent>
                      {/* Document 2 analysis */}
                    </CardContent>
                  </Card>
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="history" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Chat History</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {/* History items will go here */}
                  <div className="text-center text-muted-foreground">
                    No chat history found
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
} 