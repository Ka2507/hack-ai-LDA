import sqlite3
import json
from datetime import datetime

def init_db():
    try:
        conn = sqlite3.connect('chat_history.db')
        c = conn.cursor()
        
        # Create tables if they don't exist
        c.execute('''CREATE TABLE IF NOT EXISTS chats
                     (id INTEGER PRIMARY KEY AUTOINCREMENT,
                      file_name TEXT,
                      created_at TIMESTAMP)''')
        
        c.execute('''CREATE TABLE IF NOT EXISTS messages
                     (id INTEGER PRIMARY KEY AUTOINCREMENT,
                      chat_id INTEGER,
                      role TEXT,
                      content TEXT,
                      timestamp TIMESTAMP,
                      FOREIGN KEY (chat_id) REFERENCES chats (id))''')
        
        c.execute('''CREATE TABLE IF NOT EXISTS comparisons
                     (id INTEGER PRIMARY KEY AUTOINCREMENT,
                      chat_id INTEGER,
                      compared_file TEXT,
                      created_at TIMESTAMP,
                      FOREIGN KEY (chat_id) REFERENCES chats (id))''')
        
        conn.commit()
    except sqlite3.Error as e:
        print(f"Database error: {e}")
    finally:
        conn.close()

def save_chat(file_name, messages):
    try:
        conn = sqlite3.connect('chat_history.db')
        c = conn.cursor()
        
        # Save chat session
        c.execute('INSERT INTO chats (file_name, created_at) VALUES (?, ?)',
                  (file_name, datetime.now()))
        chat_id = c.lastrowid
        
        # Save messages
        for message in messages:
            c.execute('INSERT INTO messages (chat_id, role, content, timestamp) VALUES (?, ?, ?, ?)',
                      (chat_id, message['role'], message['content'], datetime.now()))
        
        conn.commit()
        return chat_id
    except sqlite3.Error as e:
        print(f"Error saving chat: {e}")
        return None
    finally:
        conn.close()

def get_chat_history():
    try:
        conn = sqlite3.connect('chat_history.db')
        c = conn.cursor()
        
        c.execute('''SELECT c.id, c.file_name, c.created_at, 
                     COUNT(m.id) as message_count
                     FROM chats c
                     LEFT JOIN messages m ON c.id = m.chat_id
                     GROUP BY c.id
                     ORDER BY c.created_at DESC''')
        
        history = c.fetchall()
        return history
    except sqlite3.Error as e:
        print(f"Error getting chat history: {e}")
        return []
    finally:
        conn.close()

def get_chat_messages(chat_id):
    try:
        conn = sqlite3.connect('chat_history.db')
        c = conn.cursor()
        
        c.execute('SELECT role, content FROM messages WHERE chat_id = ? ORDER BY timestamp',
                  (chat_id,))
        
        messages = [{'role': row[0], 'content': row[1]} for row in c.fetchall()]
        return messages
    except sqlite3.Error as e:
        print(f"Error getting chat messages: {e}")
        return []
    finally:
        conn.close()

def add_comparison(chat_id, compared_file):
    try:
        conn = sqlite3.connect('chat_history.db')
        c = conn.cursor()
        
        c.execute('INSERT INTO comparisons (chat_id, compared_file, created_at) VALUES (?, ?, ?)',
                  (chat_id, compared_file, datetime.now()))
        
        conn.commit()
        return True
    except sqlite3.Error as e:
        print(f"Error adding comparison: {e}")
        return False
    finally:
        conn.close()

def get_comparisons(chat_id):
    try:
        conn = sqlite3.connect('chat_history.db')
        c = conn.cursor()
        
        c.execute('SELECT compared_file, created_at FROM comparisons WHERE chat_id = ?',
                  (chat_id,))
        
        comparisons = c.fetchall()
        return comparisons
    except sqlite3.Error as e:
        print(f"Error getting comparisons: {e}")
        return []
    finally:
        conn.close() 