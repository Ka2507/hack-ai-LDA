import streamlit as st
import openai
from dotenv import load_dotenv
import os
from db import init_db, save_chat, get_chat_history, get_chat_messages, add_comparison, get_comparisons
import datetime

# Load environment variables
load_dotenv()

# Initialize database
try:
    init_db()
except Exception as e:
    st.error(f"Error initializing database: {e}")

# Initialize OpenAI client
try:
    openai.api_key = os.getenv("OPENAI_API_KEY")
    if not openai.api_key:
        st.error("OpenAI API key not found. Please check your .env file.")
except Exception as e:
    st.error(f"Error initializing OpenAI client: {e}")

# Set page config
st.set_page_config(
    page_title="Analyze Report",
    page_icon="📊",
    layout="wide"
)

# Initialize session state
if "messages" not in st.session_state:
    st.session_state.messages = []
if "current_chat_id" not in st.session_state:
    st.session_state.current_chat_id = None
if "show_comparison" not in st.session_state:
    st.session_state.show_comparison = False
if "show_history" not in st.session_state:
    st.session_state.show_history = False
if "compared_files" not in st.session_state:
    st.session_state.compared_files = []
if "current_view" not in st.session_state:
    st.session_state.current_view = "analysis"  # Can be "analysis", "comparison", or "history"

st.title("Analyze Report")

# Navigation buttons at the top
col1, col2, col3 = st.columns([1, 1, 1])

with col1:
    if st.button("← Back to Main", key="back_button"):
        try:
            # Save current chat before leaving
            if st.session_state.messages:
                chat_id = save_chat(
                    st.session_state.file.name,
                    st.session_state.messages
                )
                if chat_id:
                    st.session_state.current_chat_id = chat_id
                    st.success("Chat saved successfully!")
        except Exception as e:
            st.error(f"Error saving chat: {e}")
        st.switch_page("app.py")

with col2:
    if st.button("Compare Documents", key="compare_button"):
        st.session_state.current_view = "comparison"
        st.session_state.show_comparison = True
        st.session_state.show_history = False
        st.rerun()

with col3:
    if st.button("View History", key="history_button"):
        st.session_state.current_view = "history"
        st.session_state.show_history = True
        st.session_state.show_comparison = False
        st.rerun()

# Back to Analysis button
if st.session_state.current_view != "analysis":
    if st.button("← Back to Analysis", key="back_to_analysis"):
        st.session_state.current_view = "analysis"
        st.session_state.show_comparison = False
        st.session_state.show_history = False
        st.rerun()

if 'file' not in st.session_state or st.session_state.file is None:
    st.warning("No file uploaded. Please go back to the main page and upload a file.")
    if st.button("Go Back"):
        st.switch_page("app.py")
else:
    # Show comparison interface if selected
    if st.session_state.current_view == "comparison":
        st.header("Compare Documents")
        
        # Add current file to compared files if not already there
        if st.session_state.file.name not in [f[0] for f in st.session_state.compared_files]:
            st.session_state.compared_files.append((st.session_state.file.name, st.session_state.file))
        
        # Show currently compared files
        if st.session_state.compared_files:
            st.subheader("Currently Comparing:")
            for file_name, _ in st.session_state.compared_files:
                st.write(f"- {file_name}")
        
        # File uploader for additional documents
        compare_file = st.file_uploader("Upload another document to compare", type=["pdf"])
        if compare_file and compare_file.name not in [f[0] for f in st.session_state.compared_files]:
            if st.button("Add to Comparison"):
                st.session_state.compared_files.append((compare_file.name, compare_file))
                st.success(f"Added {compare_file.name} for comparison")
        
        # Show comparison view if we have two files
        if len(st.session_state.compared_files) >= 2:
            st.markdown("---")  # Divider line
            st.header("Document Comparison")
            
            # Create two columns for comparison
            col1, col2 = st.columns([1, 1])
            
            with col1:
                st.subheader(f"Document 1: {st.session_state.compared_files[0][0]}")
                st.write("Analysis of first document will appear here...")
                # Add your document analysis here
                
            # Add a vertical divider
            st.markdown("""
                <style>
                .vertical-divider {
                    border-left: 2px solid #ccc;
                    height: 100%;
                    margin: 0 10px;
                }
                </style>
                <div class="vertical-divider"></div>
                """, unsafe_allow_html=True)
            
            with col2:
                st.subheader(f"Document 2: {st.session_state.compared_files[1][0]}")
                st.write("Analysis of second document will appear here...")
                # Add your document analysis here

    # Show history if selected
    elif st.session_state.current_view == "history":
        st.header("Chat History")
        try:
            history = get_chat_history()
            if not history:
                st.info("No chat history found")
            else:
                for chat_id, file_name, created_at, message_count in history:
                    with st.expander(f"{file_name} - {created_at} ({message_count} messages)"):
                        messages = get_chat_messages(chat_id)
                        for msg in messages:
                            with st.chat_message(msg["role"]):
                                st.markdown(msg["content"])
                        if st.button("Load this chat", key=f"load_{chat_id}"):
                            st.session_state.messages = messages
                            st.session_state.current_chat_id = chat_id
                            st.session_state.current_view = "analysis"
                            st.success("Chat loaded successfully!")
                            st.rerun()
        except Exception as e:
            st.error(f"Error loading chat history: {e}")

    # Main analysis and chat interface
    else:
        # Create two columns
        col1, col2 = st.columns([1, 1])

        # Left column for analysis
        with col1:
            st.write(f"Analyzing file: {st.session_state.file.name}")
            
            # Placeholder for analysis results
            st.write("Analysis results will appear here...")
            
            # Example analysis sections
            st.header("Key Financial Metrics")
            st.write("Loading metrics...")
            
            st.header("Trend Analysis")
            st.write("Loading trends...")
            
            st.header("Recommendations")
            st.write("Loading recommendations...")

        # Right column for chat
        with col2:
            st.header("Chat with AI Assistant")
            
            # Display chat messages
            for message in st.session_state.messages:
                with st.chat_message(message["role"]):
                    st.markdown(message["content"])

            # Chat input
            if prompt := st.chat_input("Ask questions about the report..."):
                try:
                    # Add user message to chat history
                    st.session_state.messages.append({"role": "user", "content": prompt})
                    
                    # Display user message
                    with st.chat_message("user"):
                        st.markdown(prompt)

                    # Display assistant response
                    with st.chat_message("assistant"):
                        message_placeholder = st.empty()
                        full_response = ""
                        
                        # Get response from OpenAI
                        response = openai.ChatCompletion.create(
                            model="gpt-3.5-turbo",
                            messages=[
                                {"role": m["role"], "content": m["content"]}
                                for m in st.session_state.messages
                            ],
                            stream=True
                        )
                        
                        # Display streaming response
                        for chunk in response:
                            if chunk.choices[0].delta.get("content"):
                                full_response += chunk.choices[0].delta.content
                                message_placeholder.markdown(full_response + "▌")
                        
                        message_placeholder.markdown(full_response)
                    
                    # Add assistant response to chat history
                    st.session_state.messages.append({"role": "assistant", "content": full_response})

                    # Save chat to database
                    if not st.session_state.current_chat_id:
                        chat_id = save_chat(
                            st.session_state.file.name,
                            st.session_state.messages
                        )
                        if chat_id:
                            st.session_state.current_chat_id = chat_id
                            st.success("Chat saved successfully!")
                        else:
                            st.error("Failed to save chat")
                except Exception as e:
                    st.error(f"Error in chat: {e}")

            # Clear chat button
            if st.button("Clear Chat"):
                st.session_state.messages = []
                st.session_state.current_chat_id = None
                st.success("Chat cleared successfully!")
                st.rerun() 