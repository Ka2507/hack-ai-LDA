"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { ThemeToggle } from "@/components/theme-toggle"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { ArrowLeft, FileText, Calendar, Search, Trash2 } from "lucide-react"
import { useAuth } from "@/lib/auth-context"
import { Input } from "@/components/ui/input"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

// Mock data for file history
const mockReports = [
  {
    id: "1",
    name: "Annual Report FY24.pdf",
    date: "2024-04-15T10:30:00Z",
    size: "4.2 MB",
    queries: 12,
  },
  {
    id: "2",
    name: "Q1 Financial Statement.pdf",
    date: "2024-03-20T14:15:00Z",
    size: "2.8 MB",
    queries: 8,
  },
  {
    id: "3",
    name: "Investor Presentation 2024.pdf",
    date: "2024-02-05T09:45:00Z",
    size: "6.1 MB",
    queries: 15,
  },
  {
    id: "4",
    name: "Budget Forecast 2025.pdf",
    date: "2024-04-01T11:20:00Z",
    size: "3.5 MB",
    queries: 5,
  },
  {
    id: "5",
    name: "Quarterly Report Q4 2023.pdf",
    date: "2023-12-15T16:30:00Z",
    size: "3.9 MB",
    queries: 10,
  },
]

export default function HistoryPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [reports, setReports] = useState(mockReports)
  const router = useRouter()
  const { user } = useAuth()

  const filteredReports = reports.filter((report) => report.name.toLowerCase().includes(searchTerm.toLowerCase()))

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return new Intl.DateTimeFormat("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    }).format(date)
  }

  const handleDelete = (id: string) => {
    setReports(reports.filter((report) => report.id !== id))
  }

  const handleOpen = (id: string) => {
    router.push("/analyze")
  }

  return (
    <main className="flex min-h-screen flex-col items-center p-4 md:p-8 bg-background">
      <header className="w-full max-w-5xl mb-8">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="icon" asChild>
              <Link href="/">
                <ArrowLeft className="h-5 w-5" />
                <span className="sr-only">Back</span>
              </Link>
            </Button>
            <div className="h-8 w-8 bg-primary rounded-md"></div>
            <h1 className="text-xl font-semibold text-secondary">Report History</h1>
          </div>
          <ThemeToggle />
        </div>
      </header>

      <div className="w-full max-w-5xl">
        <Card>
          <CardHeader>
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <CardTitle>Your Reports</CardTitle>
                <CardDescription>Access your previously analyzed financial reports</CardDescription>
              </div>
              <div className="relative w-full md:w-64">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Search reports..."
                  className="pl-8"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {filteredReports.length > 0 ? (
                filteredReports.map((report) => (
                  <div
                    key={report.id}
                    className="flex items-center justify-between p-4 border border-border rounded-lg hover:bg-accent/50 transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 rounded-md bg-primary/10 flex items-center justify-center">
                        <FileText className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <h3 className="font-medium">{report.name}</h3>
                        <div className="flex items-center text-sm text-muted-foreground">
                          <Calendar className="h-3.5 w-3.5 mr-1" />
                          <span>{formatDate(report.date)}</span>
                          <span className="mx-2">•</span>
                          <span>{report.size}</span>
                          <span className="mx-2">•</span>
                          <span>{report.queries} queries</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button variant="outline" size="sm" onClick={() => handleOpen(report.id)}>
                        Open
                      </Button>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              width="16"
                              height="16"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="currentColor"
                              strokeWidth="2"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              className="lucide lucide-more-vertical"
                            >
                              <circle cx="12" cy="12" r="1" />
                              <circle cx="12" cy="5" r="1" />
                              <circle cx="12" cy="19" r="1" />
                            </svg>
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => handleOpen(report.id)}>Open</DropdownMenuItem>
                          <DropdownMenuItem>Download</DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleDelete(report.id)} className="text-red-500">
                            Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-8">
                  <FileText className="h-12 w-12 text-muted-foreground/50 mx-auto mb-4" />
                  <h3 className="text-lg font-medium">No reports found</h3>
                  <p className="text-muted-foreground">
                    {searchTerm ? "Try a different search term" : "Upload your first report to get started"}
                  </p>
                  {searchTerm && (
                    <Button variant="outline" className="mt-4" onClick={() => setSearchTerm("")}>
                      Clear search
                    </Button>
                  )}
                  {!searchTerm && (
                    <Button className="mt-4 bg-primary hover:bg-primary/90 text-primary-foreground" asChild>
                      <Link href="/">Upload a report</Link>
                    </Button>
                  )}
                </div>
              )}
            </div>
          </CardContent>
          <CardFooter className="flex justify-between">
            <p className="text-sm text-muted-foreground">
              Showing {filteredReports.length} of {reports.length} reports
            </p>
            {reports.length > 0 && (
              <Button variant="outline" size="sm" className="text-red-500" onClick={() => setReports([])}>
                <Trash2 className="h-4 w-4 mr-2" />
                Clear All
              </Button>
            )}
          </CardFooter>
        </Card>
      </div>
    </main>
  )
}
