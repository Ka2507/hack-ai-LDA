"use client"

import type React from "react"

import { useState } from "react"
import { Upload, FileText, ArrowRight, History, LogIn } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { useRouter } from "next/navigation"
import { ThemeToggle } from "@/components/theme-toggle"
import Link from "next/link"
import { useAuth } from "@/lib/auth-context"

export default function Home() {
  const [file, setFile] = useState<File | null>(null)
  const [isProcessing, setIsProcessing] = useState(false)
  const router = useRouter()
  const { user } = useAuth()

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0]
    if (selectedFile && selectedFile.type === "application/pdf") {
      setFile(selectedFile)
    }
  }

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault()
    const droppedFile = e.dataTransfer.files[0]
    if (droppedFile && droppedFile.type === "application/pdf") {
      setFile(droppedFile)
    }
  }

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault()
  }

  const handleContinue = () => {
    if (!file) return

    setIsProcessing(true)

    // Simulate file processing and saving to history if user is logged in
    setTimeout(() => {
      setIsProcessing(false)
      router.push("/analyze")
    }, 2000)
  }

  return (
    <main className="flex min-h-screen flex-col items-center p-4 md:p-8 bg-background">
      <header className="w-full max-w-5xl mb-8">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 bg-primary rounded-md"></div>
            <h1 className="text-xl font-semibold text-secondary">Financial Report Assistant</h1>
          </div>
          <div className="flex items-center gap-2">
            {user ? (
              <>
                <Button variant="outline" size="sm" asChild>
                  <Link href="/history">
                    <History className="h-4 w-4 mr-2" />
                    History
                  </Link>
                </Button>
                <Button variant="outline" size="sm" asChild>
                  <Link href="/profile">
                    <img
                      src={user.avatar || "https://github.com/shadcn.png"}
                      alt="User"
                      className="h-5 w-5 rounded-full mr-2"
                    />
                    {user.name}
                  </Link>
                </Button>
              </>
            ) : (
              <Button variant="outline" size="sm" asChild>
                <Link href="/login">
                  <LogIn className="h-4 w-4 mr-2" />
                  Sign In
                </Link>
              </Button>
            )}
            <ThemeToggle />
          </div>
        </div>
      </header>

      <div className="w-full max-w-2xl flex-1 flex flex-col justify-center">
        <Card className="border-border shadow-md">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl text-secondary dark:text-secondary-foreground">
              Upload Your Financial Report
            </CardTitle>
            <CardDescription>Upload a financial report to begin analyzing it with AI</CardDescription>
          </CardHeader>
          <CardContent>
            <div
              className="border-2 border-dashed border-border rounded-lg p-12 text-center cursor-pointer"
              onDrop={handleDrop}
              onDragOver={handleDragOver}
              onClick={() => document.getElementById("file-upload")?.click()}
            >
              <div className="flex flex-col items-center justify-center gap-4">
                <div className="h-16 w-16 rounded-full bg-accent flex items-center justify-center">
                  <Upload className="h-8 w-8 text-primary" />
                </div>
                <div className="text-lg font-medium">Drag and drop your PDF here</div>
                <div className="text-sm text-muted-foreground">
                  <span className="text-primary font-medium">Click to browse</span> or drag and drop
                </div>
                <div className="text-xs text-muted-foreground">PDF (max. 20MB)</div>
                <input id="file-upload" type="file" accept=".pdf" className="hidden" onChange={handleFileChange} />
              </div>
            </div>

            {file && (
              <div className="flex items-center justify-between p-4 mt-4 bg-accent rounded-md">
                <div className="flex items-center gap-2">
                  <FileText className="h-5 w-5 text-primary" />
                  <span className="text-sm font-medium truncate max-w-[200px] md:max-w-[400px]">{file.name}</span>
                </div>
                <Button variant="outline" size="sm" onClick={() => setFile(null)} className="text-muted-foreground">
                  Remove
                </Button>
              </div>
            )}
          </CardContent>
          <CardFooter className="flex justify-center">
            <Button
              onClick={handleContinue}
              disabled={!file || isProcessing}
              className="bg-primary hover:bg-primary/90 text-primary-foreground w-full md:w-auto"
            >
              {isProcessing ? (
                <span className="flex items-center">
                  <svg
                    className="animate-spin -ml-1 mr-3 h-5 w-5 text-white"
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                  >
                    <circle
                      className="opacity-25"
                      cx="12"
                      cy="12"
                      r="10"
                      stroke="currentColor"
                      strokeWidth="4"
                    ></circle>
                    <path
                      className="opacity-75"
                      fill="currentColor"
                      d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                    ></path>
                  </svg>
                  Processing...
                </span>
              ) : (
                <span className="flex items-center">
                  Continue
                  <ArrowRight className="ml-2 h-4 w-4" />
                </span>
              )}
            </Button>
          </CardFooter>
        </Card>
      </div>
    </main>
  )
}
