"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import {
  Send,
  ArrowLeft,
  PieChart,
  DollarSign,
  TrendingUp,
  Percent,
  Download,
  FileText,
  RefreshCw,
  MessageSquare,
  BarChart4,
  Pin,
  Clock,
  ChevronDown,
  Search,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { ThemeToggle } from "@/components/theme-toggle"
import { useRouter } from "next/navigation"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Separator } from "@/components/ui/separator"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type Message = {
  role: "user" | "assistant"
  content: string
  timestamp?: Date
  pinned?: boolean
}

type Report = {
  id: string
  name: string
  year: string
}

export default function Analyze() {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "assistant",
      content: "Hello! I've analyzed your financial report. What would you like to know about it?",
      timestamp: new Date(),
    },
  ])
  const [input, setInput] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [activeTab, setActiveTab] = useState("chat")
  const [compareMode, setCompareMode] = useState(false)
  const [selectedReports, setSelectedReports] = useState<{ primary?: string; secondary?: string }>({})
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const router = useRouter()

  // Mock previous reports data
  const previousReports: Report[] = [
    { id: "1", name: "Annual Report", year: "FY24" },
    { id: "2", name: "Annual Report", year: "FY23" },
    { id: "3", name: "Annual Report", year: "FY22" },
    { id: "4", name: "Quarterly Report Q1", year: "FY24" },
    { id: "5", name: "Quarterly Report Q4", year: "FY23" },
  ]

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const handleSubmit = (e: React.FormEvent, newInput?: string) => {
    e.preventDefault()
    const textToSubmit = newInput || input
    if (!textToSubmit.trim() || isLoading) return

    const userMessage: Message = {
      role: "user",
      content: textToSubmit,
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setIsLoading(true)

    // Simulate API response
    setTimeout(() => {
      let response = ""

      if (textToSubmit.toLowerCase().includes("revenue")) {
        response =
          "The total revenue for FY24 was $355.17 million, representing a 7.0% year-over-year growth compared to FY23."
      } else if (textToSubmit.toLowerCase().includes("profit") || textToSubmit.toLowerCase().includes("income")) {
        response = "The profit after tax for FY24 was $45.85 million, showing a 4.0% increase from the previous year."
      } else if (textToSubmit.toLowerCase().includes("roi") || textToSubmit.toLowerCase().includes("return")) {
        response = "The Return on Equity (ROE) for FY24 was 25.0%, which indicates strong financial performance."
      } else {
        response =
          "Based on the financial report, the company showed strong performance in FY24 with revenue growth of 7.0% and profit growth of 4.0%. The Return on Equity was 25.0%, and the company maintained a healthy cash position."
      }

      const assistantMessage: Message = {
        role: "assistant",
        content: response,
        timestamp: new Date(),
      }

      setMessages((prev) => [...prev, assistantMessage])
      setIsLoading(false)
    }, 1500)
  }

  const handleExport = (format: string) => {
    // Simulate export functionality
    console.log(`Exporting in ${format} format`)

    // In a real app, this would generate and download the file
    const element = document.createElement("a")

    if (format === "pdf") {
      element.setAttribute("href", "data:application/pdf;charset=utf-8,")
      element.setAttribute("download", "financial-report-analysis.pdf")
    } else if (format === "csv") {
      element.setAttribute("href", "data:text/csv;charset=utf-8,")
      element.setAttribute("download", "financial-report-analysis.csv")
    } else if (format === "txt") {
      const text = messages.map((m) => `${m.role}: ${m.content}`).join("\n\n")
      element.setAttribute("href", "data:text/plain;charset=utf-8," + encodeURIComponent(text))
      element.setAttribute("download", "financial-report-analysis.txt")
    }

    element.style.display = "none"
    document.body.appendChild(element)
    element.click()
    document.body.removeChild(element)
  }

  const togglePinMessage = (index: number) => {
    setMessages((prev) => prev.map((msg, i) => (i === index ? { ...msg, pinned: !msg.pinned } : msg)))
  }

  const handleCompareSelect = (reportId: string, type: "primary" | "secondary") => {
    setSelectedReports((prev) => ({
      ...prev,
      [type]: reportId,
    }))

    if (type === "primary" && !selectedReports.secondary) {
      setCompareMode(false)
    } else if (selectedReports.primary && selectedReports.secondary) {
      setCompareMode(true)
    }
  }

  const formatTime = (date?: Date) => {
    if (!date) return ""
    return new Intl.DateTimeFormat("en-US", {
      hour: "numeric",
      minute: "numeric",
      hour12: true,
    }).format(date)
  }

  return (
    <main className="flex min-h-screen flex-col bg-background">
      <header className="w-full p-4 border-b border-border">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="icon" onClick={() => router.push("/")} className="mr-2">
              <ArrowLeft className="h-5 w-5" />
              <span className="sr-only">Back</span>
            </Button>
            <div className="h-8 w-8 bg-primary rounded-md"></div>
            <h1 className="text-xl font-semibold text-secondary">Financial Report Assistant</h1>
          </div>
          <div className="flex items-center gap-2">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm" className="h-9 px-3 flex items-center">
                  <Download className="h-4 w-4 mr-2" />
                  <span>Export</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => handleExport("pdf")} className="flex items-center">
                  <FileText className="h-4 w-4 mr-2" />
                  <span>Export as PDF</span>
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleExport("csv")} className="flex items-center">
                  <FileText className="h-4 w-4 mr-2" />
                  <span>Export as CSV</span>
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleExport("txt")} className="flex items-center">
                  <FileText className="h-4 w-4 mr-2" />
                  <span>Export as Text</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            <ThemeToggle />
          </div>
        </div>
      </header>

      {/* New Top Navigation Bar */}
      <div className="w-full border-b border-border bg-accent/30">
        <div className="max-w-7xl mx-auto p-3 flex items-center justify-between gap-4">
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="outline"
                  className="flex-1 md:flex-none md:w-auto md:min-w-[180px] h-10 rounded-full px-4"
                  onClick={() => router.push("/")}
                >
                  <RefreshCw className="h-4 w-4 mr-2" />
                  <span className="whitespace-nowrap">Start New Analysis</span>
                </Button>
              </TooltipTrigger>
              <TooltipContent>Upload a new financial report</TooltipContent>
            </Tooltip>
          </TooltipProvider>

          <Popover>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                className="flex-1 md:flex-none md:w-auto md:min-w-[180px] h-10 rounded-full px-4"
              >
                <MessageSquare className="h-4 w-4 mr-2" />
                <span className="whitespace-nowrap">Queries / Questions</span>
                <ChevronDown className="h-4 w-4 ml-2 flex-shrink-0" />
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-80 md:w-96 p-0" align="center">
              <div className="p-3 border-b border-border">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-medium">Recent Queries</h3>
                  <Badge variant="outline" className="text-xs">
                    {messages.filter((m) => m.role === "user").length} total
                  </Badge>
                </div>
                <div className="relative">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input placeholder="Search queries..." className="pl-8" />
                </div>
              </div>
              <ScrollArea className="h-[300px]">
                <div className="p-3 space-y-3">
                  <div className="flex items-center gap-2 text-xs text-muted-foreground mb-1">
                    <Pin className="h-3 w-3" />
                    <span>Pinned</span>
                  </div>
                  {messages.filter((m) => m.role === "user" && m.pinned).length > 0 ? (
                    messages
                      .filter((m) => m.role === "user" && m.pinned)
                      .map((message, index) => (
                        <Card key={`pinned-${index}`} className="p-2 text-sm">
                          <div className="flex justify-between items-start">
                            <div className="flex-1">{message.content}</div>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-6 w-6 text-muted-foreground hover:text-foreground"
                              onClick={() => togglePinMessage(messages.findIndex((m) => m === message))}
                            >
                              <Pin className="h-3 w-3 fill-current" />
                            </Button>
                          </div>
                          <div className="flex items-center gap-1 mt-1 text-xs text-muted-foreground">
                            <Clock className="h-3 w-3" />
                            <span>{formatTime(message.timestamp)}</span>
                          </div>
                        </Card>
                      ))
                  ) : (
                    <div className="text-center text-sm text-muted-foreground py-2">No pinned queries</div>
                  )}

                  <Separator />

                  <div className="flex items-center gap-2 text-xs text-muted-foreground mb-1">
                    <Clock className="h-3 w-3" />
                    <span>Recent</span>
                  </div>
                  {messages
                    .filter((m) => m.role === "user" && !m.pinned)
                    .map((message, index) => (
                      <Card key={`recent-${index}`} className="p-2 text-sm">
                        <div className="flex justify-between items-start">
                          <div className="flex-1">{message.content}</div>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-6 w-6 text-muted-foreground hover:text-foreground"
                            onClick={() => togglePinMessage(messages.findIndex((m) => m === message))}
                          >
                            <Pin className="h-3 w-3" />
                          </Button>
                        </div>
                        <div className="flex items-center gap-1 mt-1 text-xs text-muted-foreground">
                          <Clock className="h-3 w-3" />
                          <span>{formatTime(message.timestamp)}</span>
                        </div>
                      </Card>
                    ))}
                </div>
              </ScrollArea>
              <div className="p-3 border-t border-border">
                <form
                  className="flex gap-2"
                  onSubmit={(e) => {
                    const newInput = e.currentTarget.elements.namedItem("query") as HTMLInputElement
                    handleSubmit(e, newInput.value)
                    newInput.value = ""
                  }}
                >
                  <Input name="query" placeholder="Ask a new question..." className="flex-1" />
                  <Button type="submit" size="sm">
                    <Send className="h-4 w-4" />
                  </Button>
                </form>
              </div>
            </PopoverContent>
          </Popover>

          <Popover>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                className="flex-1 md:flex-none md:w-auto md:min-w-[180px] h-10 rounded-full px-4"
              >
                <BarChart4 className="h-4 w-4 mr-2" />
                <span className="whitespace-nowrap">Compare Reports</span>
                <ChevronDown className="h-4 w-4 ml-2 flex-shrink-0" />
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-80 p-4" align="end">
              <div className="space-y-4">
                <h3 className="font-medium">Compare Financial Reports</h3>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Primary Report</label>
                  <Select
                    value={selectedReports.primary}
                    onValueChange={(value) => handleCompareSelect(value, "primary")}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select a report" />
                    </SelectTrigger>
                    <SelectContent>
                      {previousReports.map((report) => (
                        <SelectItem key={report.id} value={report.id}>
                          {report.name} {report.year}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Secondary Report (for comparison)</label>
                  <Select
                    value={selectedReports.secondary}
                    onValueChange={(value) => handleCompareSelect(value, "secondary")}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select a report" />
                    </SelectTrigger>
                    <SelectContent>
                      {previousReports
                        .filter((report) => report.id !== selectedReports.primary)
                        .map((report) => (
                          <SelectItem key={report.id} value={report.id}>
                            {report.name} {report.year}
                          </SelectItem>
                        ))}
                    </SelectContent>
                  </Select>
                </div>
                <Button
                  className="w-full bg-primary hover:bg-primary/90 text-primary-foreground h-9"
                  disabled={!selectedReports.primary || !selectedReports.secondary}
                  onClick={() => setCompareMode(true)}
                >
                  <BarChart4 className="h-4 w-4 mr-2" />
                  Compare Reports
                </Button>
              </div>
            </PopoverContent>
          </Popover>
        </div>
      </div>

      <Tabs defaultValue="chat" className="flex-1 flex flex-col" onValueChange={setActiveTab}>
        <div className="border-b border-border">
          <div className="max-w-7xl mx-auto">
            <TabsList className="h-12">
              <TabsTrigger value="chat" className="data-[state=active]:bg-background">
                <Send className="h-4 w-4 mr-2" />
                Chat
              </TabsTrigger>
              <TabsTrigger value="document" className="data-[state=active]:bg-background">
                <FileText className="h-4 w-4 mr-2" />
                Document
              </TabsTrigger>
              <TabsTrigger value="insights" className="data-[state=active]:bg-background">
                <PieChart className="h-4 w-4 mr-2" />
                Insights
              </TabsTrigger>
            </TabsList>
          </div>
        </div>

        <TabsContent value="chat" className="flex-1 flex flex-col md:flex-row p-0 m-0">
          {/* Left side - Chat interface */}
          <div className="w-full md:w-3/5 flex flex-col h-[calc(100vh-173px)]">
            <div className="p-4 border-b border-border">
              <h2 className="text-lg font-medium">Ask Questions About Your Report</h2>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {messages.map((message, index) => (
                <div key={index} className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}>
                  <div
                    className={`max-w-[80%] rounded-lg p-4 ${
                      message.role === "user" ? "bg-primary text-primary-foreground" : "bg-muted"
                    }`}
                  >
                    {message.content}
                  </div>
                </div>
              ))}
              {isLoading && (
                <div className="flex justify-start">
                  <div className="max-w-[80%] rounded-lg p-4 bg-muted">
                    <div className="flex space-x-2">
                      <div className="w-2 h-2 rounded-full bg-primary animate-bounce"></div>
                      <div
                        className="w-2 h-2 rounded-full bg-primary animate-bounce"
                        style={{ animationDelay: "0.2s" }}
                      ></div>
                      <div
                        className="w-2 h-2 rounded-full bg-primary animate-bounce"
                        style={{ animationDelay: "0.4s" }}
                      ></div>
                    </div>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            <div className="p-4 border-t border-border">
              <form onSubmit={handleSubmit} className="flex gap-2">
                <Textarea
                  placeholder="Ask a question about the financial report..."
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  className="flex-1 resize-none min-h-[60px] max-h-[120px] border-border focus-visible:ring-primary"
                />
                <Button
                  type="submit"
                  disabled={!input.trim() || isLoading}
                  className="bg-primary hover:bg-primary/90 text-primary-foreground self-end h-10 px-3"
                >
                  <Send className="h-4 w-4" />
                </Button>
              </form>
            </div>
          </div>

          {/* Right side - Infographic */}
          <div className="w-full md:w-2/5 border-l border-border overflow-y-auto h-[calc(100vh-173px)]">
            <div className="p-4 border-b border-border">
              <h2 className="text-lg font-medium">{compareMode ? "Financial Comparison" : "Financial Insights"}</h2>
              {compareMode && (
                <div className="flex items-center gap-2 mt-1 text-sm">
                  <Badge variant="outline" className="bg-primary/10">
                    {previousReports.find((r) => r.id === selectedReports.primary)?.name}{" "}
                    {previousReports.find((r) => r.id === selectedReports.primary)?.year}
                  </Badge>
                  <span>vs</span>
                  <Badge variant="outline" className="bg-blue-500/10">
                    {previousReports.find((r) => r.id === selectedReports.secondary)?.name}{" "}
                    {previousReports.find((r) => r.id === selectedReports.secondary)?.year}
                  </Badge>
                </div>
              )}
            </div>

            <div className="p-4 space-y-6">
              {/* KPI Cards */}
              <div className="grid grid-cols-2 gap-4">
                {compareMode ? (
                  // Comparison view
                  <>
                    <Card>
                      <CardContent className="p-4">
                        <div className="flex justify-between">
                          <div className="flex flex-col items-center">
                            <DollarSign className="h-6 w-6 text-primary mb-1" />
                            <p className="text-xs text-muted-foreground">Revenue</p>
                            <p className="text-lg font-bold">$355.17M</p>
                            <p className="text-xs text-green-500 flex items-center">
                              <TrendingUp className="h-3 w-3 mr-1" /> +7.0%
                            </p>
                          </div>
                          <div className="flex flex-col items-center">
                            <DollarSign className="h-6 w-6 text-blue-500 mb-1" />
                            <p className="text-xs text-muted-foreground">Revenue</p>
                            <p className="text-lg font-bold">$331.93M</p>
                            <p className="text-xs text-green-500 flex items-center">
                              <TrendingUp className="h-3 w-3 mr-1" /> +5.2%
                            </p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardContent className="p-4">
                        <div className="flex justify-between">
                          <div className="flex flex-col items-center">
                            <DollarSign className="h-6 w-6 text-primary mb-1" />
                            <p className="text-xs text-muted-foreground">Net Profit</p>
                            <p className="text-lg font-bold">$45.85M</p>
                            <p className="text-xs text-green-500 flex items-center">
                              <TrendingUp className="h-3 w-3 mr-1" /> +4.0%
                            </p>
                          </div>
                          <div className="flex flex-col items-center">
                            <DollarSign className="h-6 w-6 text-blue-500 mb-1" />
                            <p className="text-xs text-muted-foreground">Net Profit</p>
                            <p className="text-lg font-bold">$44.09M</p>
                            <p className="text-xs text-green-500 flex items-center">
                              <TrendingUp className="h-3 w-3 mr-1" /> +3.5%
                            </p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardContent className="p-4">
                        <div className="flex justify-between">
                          <div className="flex flex-col items-center">
                            <Percent className="h-6 w-6 text-primary mb-1" />
                            <p className="text-xs text-muted-foreground">ROE</p>
                            <p className="text-lg font-bold">25.0%</p>
                            <p className="text-xs text-green-500 flex items-center">
                              <TrendingUp className="h-3 w-3 mr-1" /> +2.1%
                            </p>
                          </div>
                          <div className="flex flex-col items-center">
                            <Percent className="h-6 w-6 text-blue-500 mb-1" />
                            <p className="text-xs text-muted-foreground">ROE</p>
                            <p className="text-lg font-bold">22.9%</p>
                            <p className="text-xs text-green-500 flex items-center">
                              <TrendingUp className="h-3 w-3 mr-1" /> +1.5%
                            </p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardContent className="p-4">
                        <div className="flex justify-between">
                          <div className="flex flex-col items-center">
                            <DollarSign className="h-6 w-6 text-primary mb-1" />
                            <p className="text-xs text-muted-foreground">Cash</p>
                            <p className="text-lg font-bold">$115.60M</p>
                            <p className="text-xs text-green-500 flex items-center">
                              <TrendingUp className="h-3 w-3 mr-1" /> +12.3%
                            </p>
                          </div>
                          <div className="flex flex-col items-center">
                            <DollarSign className="h-6 w-6 text-blue-500 mb-1" />
                            <p className="text-xs text-muted-foreground">Cash</p>
                            <p className="text-lg font-bold">$102.94M</p>
                            <p className="text-xs text-green-500 flex items-center">
                              <TrendingUp className="h-3 w-3 mr-1" /> +8.7%
                            </p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </>
                ) : (
                  // Standard view
                  <>
                    <Card>
                      <CardContent className="p-4 flex flex-col items-center">
                        <DollarSign className="h-8 w-8 text-primary mb-2" />
                        <p className="text-sm text-muted-foreground">Revenue</p>
                        <p className="text-xl font-bold">$355.17M</p>
                        <p className="text-xs text-green-500 flex items-center">
                          <TrendingUp className="h-3 w-3 mr-1" /> +7.0%
                        </p>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardContent className="p-4 flex flex-col items-center">
                        <DollarSign className="h-8 w-8 text-primary mb-2" />
                        <p className="text-sm text-muted-foreground">Net Profit</p>
                        <p className="text-xl font-bold">$45.85M</p>
                        <p className="text-xs text-green-500 flex items-center">
                          <TrendingUp className="h-3 w-3 mr-1" /> +4.0%
                        </p>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardContent className="p-4 flex flex-col items-center">
                        <Percent className="h-8 w-8 text-primary mb-2" />
                        <p className="text-sm text-muted-foreground">ROE</p>
                        <p className="text-xl font-bold">25.0%</p>
                        <p className="text-xs text-green-500 flex items-center">
                          <TrendingUp className="h-3 w-3 mr-1" /> +2.1%
                        </p>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardContent className="p-4 flex flex-col items-center">
                        <DollarSign className="h-8 w-8 text-primary mb-2" />
                        <p className="text-sm text-muted-foreground">Cash Balance</p>
                        <p className="text-xl font-bold">$115.60M</p>
                        <p className="text-xs text-green-500 flex items-center">
                          <TrendingUp className="h-3 w-3 mr-1" /> +12.3%
                        </p>
                      </CardContent>
                    </Card>
                  </>
                )}
              </div>

              {/* Revenue Chart */}
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-md">
                    {compareMode ? "Quarterly Revenue Comparison (in millions)" : "Quarterly Revenue (in millions)"}
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-4">
                  {compareMode ? (
                    <div className="h-64 flex items-end justify-between gap-2">
                      {[
                        { current: 82.5, previous: 78.3 },
                        { current: 87.3, previous: 82.1 },
                        { current: 90.1, previous: 85.6 },
                        { current: 95.3, previous: 89.9 },
                      ].map((quarter, i) => (
                        <div key={i} className="flex flex-col items-center gap-2">
                          <div className="flex items-end gap-1">
                            <div
                              className="bg-primary/80 w-6 rounded-t-md"
                              style={{ height: `${(quarter.current / 100) * 200}px` }}
                            ></div>
                            <div
                              className="bg-blue-500/80 w-6 rounded-t-md"
                              style={{ height: `${(quarter.previous / 100) * 200}px` }}
                            ></div>
                          </div>
                          <span className="text-xs text-muted-foreground">Q{i + 1}</span>
                          <div className="flex gap-2 text-xs">
                            <span className="font-medium text-primary">${quarter.current}</span>
                            <span className="font-medium text-blue-500">${quarter.previous}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="h-64 flex items-end justify-between gap-2">
                      {[82.5, 87.3, 90.1, 95.3].map((value, i) => (
                        <div key={i} className="flex flex-col items-center gap-2">
                          <div
                            className="bg-primary/80 w-12 rounded-t-md"
                            style={{ height: `${(value / 100) * 200}px` }}
                          ></div>
                          <span className="text-xs text-muted-foreground">Q{i + 1}</span>
                          <span className="text-sm font-medium">${value}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Revenue Distribution */}
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-md">Revenue Distribution</CardTitle>
                </CardHeader>
                <CardContent className="p-4">
                  {compareMode ? (
                    <div className="flex flex-col md:flex-row justify-center gap-4 mb-4">
                      <div className="flex flex-col items-center">
                        <div className="relative w-36 h-36">
                          <PieChart className="w-full h-full text-primary" />
                          <div className="absolute inset-0 flex items-center justify-center">
                            <span className="text-sm font-medium">FY24</span>
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-2 mt-2">
                          <div className="flex items-center gap-2">
                            <div className="w-3 h-3 rounded-full bg-primary"></div>
                            <span className="text-xs">NA (45%)</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <div className="w-3 h-3 rounded-full bg-blue-500"></div>
                            <span className="text-xs">EU (30%)</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <div className="w-3 h-3 rounded-full bg-green-500"></div>
                            <span className="text-xs">APAC (20%)</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                            <span className="text-xs">ROW (5%)</span>
                          </div>
                        </div>
                      </div>
                      <div className="flex flex-col items-center">
                        <div className="relative w-36 h-36">
                          <PieChart className="w-full h-full text-blue-500" />
                          <div className="absolute inset-0 flex items-center justify-center">
                            <span className="text-sm font-medium">FY23</span>
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-2 mt-2">
                          <div className="flex items-center gap-2">
                            <div className="w-3 h-3 rounded-full bg-primary"></div>
                            <span className="text-xs">NA (42%)</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <div className="w-3 h-3 rounded-full bg-blue-500"></div>
                            <span className="text-xs">EU (32%)</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <div className="w-3 h-3 rounded-full bg-green-500"></div>
                            <span className="text-xs">APAC (18%)</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                            <span className="text-xs">ROW (8%)</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <>
                      <div className="flex justify-center mb-4">
                        <div className="relative w-48 h-48">
                          <PieChart className="w-full h-full text-muted-foreground" />
                          <div className="absolute inset-0 flex items-center justify-center">
                            <span className="text-sm font-medium">FY24</span>
                          </div>
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <div className="flex items-center gap-2">
                          <div className="w-3 h-3 rounded-full bg-primary"></div>
                          <span className="text-sm">North America (45%)</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="w-3 h-3 rounded-full bg-blue-500"></div>
                          <span className="text-sm">Europe (30%)</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="w-3 h-3 rounded-full bg-green-500"></div>
                          <span className="text-sm">Asia Pacific (20%)</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                          <span className="text-sm">Rest of World (5%)</span>
                        </div>
                      </div>
                    </>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="document" className="flex-1 p-0 m-0">
          <div className="h-[calc(100vh-173px)] flex flex-col items-center justify-center bg-muted/30 p-4">
            <div className="max-w-3xl w-full bg-card p-6 rounded-lg shadow-lg border border-border">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold">Annual Report FY24</h2>
                <Button variant="outline" size="sm">
                  <FileText className="h-4 w-4 mr-2" />
                  Full Screen
                </Button>
              </div>
              <div className="aspect-[3/4] bg-muted rounded-md flex items-center justify-center">
                <FileText className="h-16 w-16 text-muted-foreground/50" />
                <p className="text-muted-foreground ml-2">PDF Viewer</p>
              </div>
              <div className="mt-4 flex justify-between">
                <Button variant="outline" size="sm">
                  Previous Page
                </Button>
                <span className="text-sm text-muted-foreground">Page 1 of 42</span>
                <Button variant="outline" size="sm">
                  Next Page
                </Button>
              </div>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="insights" className="flex-1 p-0 m-0">
          <div className="h-[calc(100vh-173px)] overflow-y-auto p-6">
            <div className="max-w-5xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="md:col-span-2">
                <CardHeader>
                  <CardTitle>Financial Highlights</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="bg-accent p-4 rounded-lg">
                      <p className="text-sm text-muted-foreground">Revenue</p>
                      <p className="text-2xl font-bold">$355.17M</p>
                      <p className="text-xs text-green-500 flex items-center">
                        <TrendingUp className="h-3 w-3 mr-1" /> +7.0% from FY23
                      </p>
                    </div>
                    <div className="bg-accent p-4 rounded-lg">
                      <p className="text-sm text-muted-foreground">Net Profit</p>
                      <p className="text-2xl font-bold">$45.85M</p>
                      <p className="text-xs text-green-500 flex items-center">
                        <TrendingUp className="h-3 w-3 mr-1" /> +4.0% from FY23
                      </p>
                    </div>
                    <div className="bg-accent p-4 rounded-lg">
                      <p className="text-sm text-muted-foreground">ROE</p>
                      <p className="text-2xl font-bold">25.0%</p>
                      <p className="text-xs text-green-500 flex items-center">
                        <TrendingUp className="h-3 w-3 mr-1" /> +2.1% from FY23
                      </p>
                    </div>
                    <div className="bg-accent p-4 rounded-lg">
                      <p className="text-sm text-muted-foreground">Cash Balance</p>
                      <p className="text-2xl font-bold">$115.60M</p>
                      <p className="text-xs text-green-500 flex items-center">
                        <TrendingUp className="h-3 w-3 mr-1" /> +12.3% from FY23
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Revenue Breakdown</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex justify-center mb-4">
                    <div className="relative w-48 h-48">
                      <PieChart className="w-full h-full text-muted-foreground" />
                      <div className="absolute inset-0 flex items-center justify-center">
                        <span className="text-sm font-medium">FY24</span>
                      </div>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full bg-primary"></div>
                        <span className="text-sm">North America</span>
                      </div>
                      <span className="text-sm font-medium">45%</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full bg-blue-500"></div>
                        <span className="text-sm">Europe</span>
                      </div>
                      <span className="text-sm font-medium">30%</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full bg-green-500"></div>
                        <span className="text-sm">Asia Pacific</span>
                      </div>
                      <span className="text-sm font-medium">20%</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                        <span className="text-sm">Rest of World</span>
                      </div>
                      <span className="text-sm font-medium">5%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Quarterly Performance</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-64 flex items-end justify-between gap-2">
                    {[82.5, 87.3, 90.1, 95.3].map((value, i) => (
                      <div key={i} className="flex flex-col items-center gap-2">
                        <div
                          className="bg-primary/80 w-12 rounded-t-md"
                          style={{ height: `${(value / 100) * 200}px` }}
                        ></div>
                        <span className="text-xs text-muted-foreground">Q{i + 1}</span>
                        <span className="text-sm font-medium">${value}M</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card className="md:col-span-2">
                <CardHeader>
                  <CardTitle>Key Insights</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3">
                    <li className="flex items-center gap-2">
                      <div className="h-2 w-2 rounded-full bg-primary"></div>
                      <span>
                        Revenue grew by 7.0% year-over-year, driven primarily by expansion in North American markets.
                      </span>
                    </li>
                    <li className="flex items-center gap-2">
                      <div className="h-2 w-2 rounded-full bg-primary"></div>
                      <span>Profit margins improved by 0.5 percentage points due to operational efficiencies.</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <div className="h-2 w-2 rounded-full bg-primary"></div>
                      <span>Cash reserves increased by 12.3%, providing strong liquidity for future investments.</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <div className="h-2 w-2 rounded-full bg-primary"></div>
                      <span>
                        Q4 showed the strongest performance with 10.2% growth compared to Q4 of previous year.
                      </span>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </main>
  )
}
