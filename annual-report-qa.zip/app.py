import streamlit as st
from dotenv import load_dotenv
import os

# Load environment variables
load_dotenv()

# Set page config
st.set_page_config(
    page_title="Financial Report Assistant",
    page_icon="📊",
    layout="wide"
)

# Initialize session state
if "file" not in st.session_state:
    st.session_state.file = None

st.title("Financial Report Assistant")

# File uploader
uploaded_file = st.file_uploader(
    "Upload a financial report (PDF)",
    type=["pdf"],
    help="PDF files only (max. 20MB)"
)

if uploaded_file is not None:
    st.session_state.file = uploaded_file
    st.success(f"File uploaded: {uploaded_file.name}")
    
    # Button to proceed to analysis
    if st.button("Analyze Report"):
        st.switch_page("pages/analyze.py") 